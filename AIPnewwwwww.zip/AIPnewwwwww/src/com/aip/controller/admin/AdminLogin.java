package com.aip.controller.admin;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.aip.mode.impl.UserDAOImpl;
import com.aip.model.entity.User;
import com.aip.model.inter.UserDAO;

/**
 * Servlet implementation class LoginUser
 */
@WebServlet("/AdminLogin.do")
public class  AdminLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdminLogin() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();		
		String Admin_id=request.getParameter("Admin_Id");    
		String password=request.getParameter("password");
		
		if(Admin_id.equalsIgnoreCase("Admin") && password.equals("admin@123"))
		{
			HttpSession hs=request.getSession();
			hs.setAttribute("admin", Admin_id);
			System.out.println("Pass");
			//RequestDispatcher rd=request.getRequestDispatcher("GetAllUser.do");
			RequestDispatcher rd=request.getRequestDispatcher("defaulter.jsp");
			//pw.println("<span style=color:green;size:20px; >User Login Successfully</span>");			
			rd.forward(request, response);
		}
		else
		{
			System.out.println("Fail");
			RequestDispatcher rd=request.getRequestDispatcher("userlogin.jsp");
			request.setAttribute("msg", "Password or User_id is incorrect");			
			//pw.println("<center><span style=color:red;size:20px>Password or User_id is incorrect </span></center>");
			rd.forward(request, response);
		}
	}

}
