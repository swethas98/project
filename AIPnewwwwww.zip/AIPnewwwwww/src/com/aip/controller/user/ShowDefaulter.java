package com.aip.controller.user;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.aip.mode.impl.DefaultDAOImpl;
import com.aip.model.entity.Defaulter;
import com.aip.model.inter.DefaulterDAO;

/**
 * Servlet implementation class ShowDefaulter
 */
@WebServlet("/ShowDefaulter.do")
public class ShowDefaulter extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShowDefaulter() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession hs=request.getSession();
		PrintWriter pw=response.getWriter();
		if(hs.getAttribute("admin")!=null)
		{
		String defaulter_status=request.getParameter("defaulter_status");
		System.out.println("Re_Defaults :"+defaulter_status);
		DefaulterDAO dd=new DefaultDAOImpl();
		List<Defaulter> deflist=(List<Defaulter>)dd.getDefaulterByStatus(defaulter_status);		
		hs.setAttribute("defaulterList", deflist);
		hs.setAttribute("defaulter_status1", defaulter_status);
		request.getRequestDispatcher("showdefaulter.jsp").include(request, response);
		}else
		{
			pw.println("<script type =text/javascript>");
			pw.println("alert('Please Login')");
			pw.println("</script>");
			request.getRequestDispatcher("home.jsp").include(request, response);
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
