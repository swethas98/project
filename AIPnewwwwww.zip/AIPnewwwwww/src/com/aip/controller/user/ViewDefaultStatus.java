package com.aip.controller.user;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.aip.mode.impl.DefaultDAOImpl;
import com.aip.mode.impl.UserDAOImpl;
import com.aip.model.entity.Defaulter;
import com.aip.model.entity.User;
import com.aip.model.inter.DefaulterDAO;
import com.aip.model.inter.UserDAO;

/**
 * Servlet implementation class ViewDefaultStatus
 */
@WebServlet("/ViewDefaultStatus.do")
public class ViewDefaultStatus extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ViewDefaultStatus() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();		
		String User_id=request.getParameter("userid");    
		DefaulterDAO dd= new DefaultDAOImpl();
		Defaulter defaulter=dd.getDefaulterById(User_id);
		request.setAttribute("defaulterObj", defaulter);
		request.getRequestDispatcher("defaultdisplay.jsp").include(request, response);			
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
