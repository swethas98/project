package com.aip.model.entity;

import java.io.Serializable;

public class User implements Serializable{
	private String First_name;
	private String Last_name;
	private int Age;
	private String Gender;
	private String Contact_number;
	private String city;
	private String state;
	private String User_id;
	private String password;
	public String getFirst_name() {
		return First_name;
	}
	public void setFirst_name(String first_name) {
		First_name = first_name;
	}
	public String getLast_name() {
		return Last_name;
	}
	public void setLast_name(String last_name) {
		Last_name = last_name;
	}
	public int getAge() {
		return Age;
	}
	public void setAge(int age) {
		Age = age;
	}
	public String getGender() {
		return Gender;
	}
	public void setGender(String gender) {
		Gender = gender;
	}
	public String getContact_number() {
		return Contact_number;
	}
	public void setContact_number(String contact_number) {
		Contact_number = contact_number;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getUser_id() {
		return User_id;
	}
	public void setUser_id(String user_id) {
		User_id = user_id;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public User(String first_name, String last_name, int age, String gender, String contact_number, String city,
			String state, String user_id, String password) {
		super();
		First_name = first_name;
		Last_name = last_name;
		Age = age;
		Gender = gender;
		Contact_number = contact_number;
		this.city = city;
		this.state = state;
		this.User_id = user_id;
		this.password = password;
	}
	public User(String first_name, String last_name, int age, String gender, String contact_number, String city,
			String state, String user_id) {
		super();
		First_name = first_name;
		Last_name = last_name;
		Age = age;
		Gender = gender;
		Contact_number = contact_number;
		this.city = city;
		this.state = state;
		this.User_id = user_id;
		
	}
	public User(String user_id, String password) {
		super();
		User_id = user_id;
		this.password = password;
	}
	
	public User() {
		super();
		
	}

	

}
