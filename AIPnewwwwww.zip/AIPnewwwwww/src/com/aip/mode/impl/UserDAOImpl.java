package com.aip.mode.impl;



import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.aip.model.entity.User;
import com.aip.model.inter.UserDAO;
import com.aip.model.entity.ConnectionFactory;

public  class UserDAOImpl implements UserDAO{
	Connection con=null;
	public UserDAOImpl() {
		con=ConnectionFactory.openConn();
	}

	@Override
	public int addUser(User abc) {
		
		int status=0;
		try {
			PreparedStatement ps=con.prepareStatement("insert into registration_form values(?,?,?,?,?,?,?,?,?)");
            ps.setString(1,abc.getFirst_name());
            ps.setString(2,abc.getLast_name());
            ps.setInt(3,abc.getAge());
            ps.setString(4,abc.getGender());
            ps.setString(5,abc .getContact_number());
            ps.setString(6,abc.getCity());
            ps.setString(7,abc.getState());
            ps.setString(8,abc.getUser_id());
            ps.setString(9,abc.getPassword());
            status=ps.executeUpdate();

		}catch (Exception e) {
			System.out.println("Error in Insert User "+e);
		}
		return status;
		
	}

	@Override
	public int updateUser(User abc) {
		int status=0;
		try {
			PreparedStatement ps=con.prepareStatement("update  registration_form set First_name=?,Last_name=?,Age=?,Gender=?,Contact_number=?,City=?,State=? where User_id=? ");
			ps.setString(1,abc.getFirst_name());
            ps.setString(2,abc.getLast_name());
            ps.setInt(3,abc.getAge());
            ps.setString(4,abc.getGender());
            ps.setString(5,abc.getContact_number());
            ps.setString(6,abc.getCity());
            ps.setString(7,abc.getState());
            ps.setString(8,abc.getUser_id());
            
            
           
            status=ps.executeUpdate();

		}catch (Exception e) {
			System.out.println("Error in Updating User "+e);
		}
		return status;
		
	}

	@Override
	public List<User> getAllUser() {
		// TODO Auto-generated method stub
		List<User> userlist=new ArrayList<User>();
		try {
			Statement st=con.createStatement();            
            ResultSet rs=st.executeQuery("select User_id from registration_form");
            while(rs.next())
            {
            	User user=new User();
            	user.setUser_id(rs.getString(1));
            	userlist.add(user);
            }
            
		}catch (Exception e) {
			System.out.println("Error in Get All User "+e);
		}
		return userlist;
	}
	@Override
	public User getByUserId(String userid) {
		// TODO Auto-generated method stub
		User user=null;
		try {
			PreparedStatement ps=con.prepareStatement("select * from registration_form where User_id=?");
            ps.setString(1,userid);            
            ResultSet rs=ps.executeQuery();
            if(rs.next())
            {          
            	user=new User();
            	user.setFirst_name(rs.getString(1));
            	user.setLast_name(rs.getString(2));
            	user.setAge(rs.getInt(3));
            	user.setGender(rs.getString(4));
            	user.setContact_number(rs.getString(5));
            	user.setCity(rs.getString(6));
            	user.setState(rs.getString(7));            	
            }
            
		}catch (Exception e) {
			System.out.println("Error in Get All User "+e);
		}
		return user;
	}

	@Override
	public int deleteUser(String userid) {
		
		int status=0;
		try {
			PreparedStatement ps=con.prepareStatement("delete from registration_form where User_id=?");
            ps.setString(1,userid);
           
            status=ps.executeUpdate();

		}catch (Exception e) {
			System.out.println("Error in Delete User "+e);
		}
		return status;
	}

	@Override
	public int userLogin(User abc) {
		int status=0;
		try {
			PreparedStatement ps=con.prepareStatement("select User_id,password from registration_form where User_id=? and password=?");
            ps.setString(1,abc.getUser_id());
            ps.setString(2,abc.getPassword());
            ResultSet rs=ps.executeQuery();
         
            if(rs.next())
            	status=1;
            
            else
            	status=0;
            System.out.println(status+"\t"+abc.getUser_id()+"\t"+abc.getPassword());
		}catch (Exception e) {
			System.out.println("Error in Login User "+e);
		}
		return status;
	}

	@Override
	public int defaultStatus(User abc) {
		// TODO Auto-generated method stub
		return 0;
	}
	
}
