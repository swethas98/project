package com.aip.controller.user;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.aip.model.entity.User;
import com.aip.model.inter.UserDAO;
import com.aip.mode.impl.UserDAOImpl;


/**
 * Servlet implementation class AddUser
 */
@WebServlet("/AddUser.do")
public class AddUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddUser() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		String firstname=request.getParameter("fname");
		String lastname=request.getParameter("lname");
		int age=Integer.parseInt(request.getParameter("Age"));
		String gender=request.getParameter("gender");
		String Contact_number=request.getParameter("contact_number");
		String city=request.getParameter("city");
		String state=request.getParameter("state");
		String User_id=request.getParameter("User_id");
		String password=request.getParameter("password");
		User abc=new User(firstname, lastname, age, gender, Contact_number, city, state, User_id, password);
		UserDAO abcdao=new UserDAOImpl();
		int status=abcdao.addUser(abc);
		
		if(status==1)
		{
			RequestDispatcher rd=request.getRequestDispatcher("registration_form.jsp");
			//pw.println("<span style=color:green;size:20px>User Added Successfully</span>");
			request.setAttribute("msg", "User added successfully");
			rd.include(request, response);
		}
		else
		{
			RequestDispatcher rd=request.getRequestDispatcher("registration_form.jsp");
			//pw.println("<span style=color:red;size:20px>Failed User Adding </span>");
			request.setAttribute("msg", "Failed User adding");
			rd.include(request, response);
		}
	}
}


